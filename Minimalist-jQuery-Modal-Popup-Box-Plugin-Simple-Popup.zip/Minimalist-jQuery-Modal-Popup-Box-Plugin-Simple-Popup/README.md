# Simple jQuery Popup Plugin

for call:

    $(function() {
      $(".js__p_start, .js__p_another_start").simplePopup();
    });
