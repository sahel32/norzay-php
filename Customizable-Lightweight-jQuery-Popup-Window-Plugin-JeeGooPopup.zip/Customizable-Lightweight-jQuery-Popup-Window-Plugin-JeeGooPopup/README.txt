Jeegoopopup is a flexible lightweight jquery popup plugin primarily designed to be used in applications. 
It can be configured as a confirm dialog, tooltip, colorpicker, image popup and more.

Features:
- Easy to implement.
- Draggable.
- Resizable.
- Skinable, multiple skins included.
- Display html/text content or url.
- Numerous properties and methods to configure appearance, position en behavior.
- Multiple popups but only one popup shown at any time.